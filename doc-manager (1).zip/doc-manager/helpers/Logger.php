<?php
/**
 * Logger.php
 * 
 * Helper para registrar errores, advertencias o acciones importantes del plugin.
 */

defined('ABSPATH') || exit;

class DM_Logger {
    /**
     * Escribe un mensaje en el archivo de log del plugin.
     *
     * @param string $message Mensaje a registrar
     */
    public static function log($message) {
        $log_file = plugin_dir_path(__DIR__) . 'logs/error.log';

        // Asegura que la carpeta logs exista
        if (!file_exists(dirname($log_file))) {
            mkdir(dirname($log_file), 0755, true);
        }

        // Formato del mensaje
        $date = date('Y-m-d H:i:s');
        $formatted_message = "[$date] $message\n";

        // Escribe en el archivo
        error_log($formatted_message, 3, $log_file);
    }
}
