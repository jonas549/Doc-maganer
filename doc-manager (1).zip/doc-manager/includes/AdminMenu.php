<?php
/**
 * AdminMenu.php
 * 
 * Define el menú de administración y páginas del plugin.
 */

defined('ABSPATH') || exit;

// Registrar el menú principal del plugin
add_action('admin_menu', function () {
    // Menú principal
    add_menu_page(
        'Gestión de Documentos',
        'Documentos',
        'manage_options',
        'doc-manager',
        'dm_render_dashboard',
        'dashicons-media-document',
        6
    );

    // Subpágina principal (repetida como submenú)
    add_submenu_page(
        'doc-manager',
        'Gestión de Documentos',
        'Todos los Documentos',
        'manage_options',
        'doc-manager',
        'dm_render_dashboard'
    );

    // Submenú: Categorías
    add_submenu_page(
        'doc-manager',
        'Categorías de Documentos',
        'Categorías',
        'manage_options',
        'edit-tags.php?taxonomy=document_category&post_type=attachment'
    );

    // Submenú: Carpetas
    add_submenu_page(
        'doc-manager',
        'Carpetas de Documentos',
        'Carpetas',
        'manage_options',
        'edit-tags.php?taxonomy=document_folder&post_type=attachment'
    );

    // Submenú oculto: edición de documentos general (por ahora Word/PPT)
    add_submenu_page(
        null,
        'Editar Documento',
        'Editar',
        'manage_options',
        'doc-manager-edit',
        'dm_render_edit_document'
    );

    // 🆕 Submenú oculto: editor de Excel con Luckysheet
    add_submenu_page(
        null,
        'Editar Excel',
        'Editar Excel',
        'manage_options',
        'doc-manager-edit-excel',
        ['DM_LuckysheetEditor', 'render_editor_page']
    );
});

// Registrar taxonomías: categorías y carpetas
add_action('init', function () {
    register_taxonomy(
        'document_category',
        'attachment',
        [
            'label'        => 'Categorías de Documentos',
            'hierarchical' => true,
            'public'       => true,
            'show_ui'      => true,
            'show_admin_column' => false,
            'rewrite'      => ['slug' => 'categoria-documento'],
        ]
    );

    register_taxonomy(
        'document_folder',
        'attachment',
        [
            'label'        => 'Carpetas de Documentos',
            'hierarchical' => true,
            'public'       => true,
            'show_ui'      => true,
            'show_admin_column' => false,
            'rewrite'      => ['slug' => 'carpeta-documento'],
        ]
    );
});

/**
 * Página principal del plugin
 */
function dm_render_dashboard() {
    echo '<div class="wrap">';
    echo '<h1>Gestión de Documentos</h1>';
    echo '<p>Desde aquí podrás subir, organizar y editar documentos.</p>';

    if (function_exists('dm_render_upload_form')) {
        dm_render_upload_form();
    }

    if (function_exists('dm_get_uploaded_documents')) {
        include DM_PLUGIN_PATH . 'templates/list-documents.php';
    }

    echo '</div>';
}

/**
 * Página oculta para edición de documentos (general)
 */
function dm_render_edit_document() {
    include DM_PLUGIN_PATH . 'templates/edit-document.php';
}
