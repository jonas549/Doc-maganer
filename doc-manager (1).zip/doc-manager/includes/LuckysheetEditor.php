<?php
/**
 * LuckysheetEditor.php
 * 
 * Controlador del editor de Excel con Luckysheet.
 */

defined('ABSPATH') || exit;

class DM_LuckysheetEditor {
    /**
     * Renderiza la vista del editor con Luckysheet
     */
    public static function render_editor_page() {
        if (!isset($_GET['doc_id']) || !is_numeric($_GET['doc_id'])) {
            echo '<p>Error: ID de documento no válido.</p>';
            return;
        }

        $doc_id = intval($_GET['doc_id']);
        $mime   = get_post_mime_type($doc_id);

        if ($mime !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
            echo '<p>Este archivo no es un Excel válido.</p>';
            return;
        }

        $file_url  = wp_get_attachment_url($doc_id);
        $file_path = get_attached_file($doc_id);
        $title     = get_the_title($doc_id);
        $last_modified = get_post_meta($doc_id, '_dm_last_modified', true);
        if (!$last_modified) {
            $last_modified = get_post_field('post_modified', $doc_id);
        }

        // Pasar variables a la plantilla
        $context = [
            'doc_id'         => $doc_id,
            'file_url'       => $file_url,
            'file_path'      => $file_path,
            'title'          => $title,
            'last_modified'  => $last_modified,
        ];

        // Incluye la vista del editor
        include DM_PLUGIN_PATH . 'templates/editor-excel.php';
    }
}
