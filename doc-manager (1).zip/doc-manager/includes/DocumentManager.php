<?php
/**
 * DocumentManager.php
 * 
 * Controlador principal para gestionar los documentos:
 * listado, filtrado, borrado y futuros añadidos como versión, permisos, etc.
 */

defined('ABSPATH') || exit;

/**
 * Obtiene una lista de documentos subidos por el plugin.
 * Opcionalmente puede filtrarse por tipo MIME o categoría (en el futuro).
 */
function dm_get_uploaded_documents($args = []) {
    $defaults = [
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'posts_per_page' => -1,
        'meta_query'     => [],
        'orderby'        => 'date',
        'order'          => 'DESC',
        'post_mime_type' => [
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'application/pdf',
            'text/csv'
        ]
    ];

    $query_args = wp_parse_args($args, $defaults);
    $query = new WP_Query($query_args);
    return $query->posts;
}

/**
 * Borra un documento subido desde el plugin.
 */
function dm_delete_document($attachment_id) {
    if (!current_user_can('delete_posts')) {
        DM_Logger::log("Intento no autorizado de borrar archivo con ID: $attachment_id");
        return false;
    }

    $deleted = wp_delete_attachment($attachment_id, true);

    if ($deleted) {
        DM_Logger::log("Documento eliminado correctamente: ID $attachment_id");
        return true;
    } else {
        DM_Logger::log("Error al eliminar documento: ID $attachment_id");
        return false;
    }
}

/**
 * (Futuro) Asignar categorías o metadatos personalizados
 * También podríamos registrar aquí las versiones.
 */
