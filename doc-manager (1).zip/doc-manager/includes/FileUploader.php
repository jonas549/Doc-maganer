<?php
/**
 * FileUploader.php
 * 
 * Maneja la lógica de subida y eliminación de archivos (Excel, Word, PPT).
 */

defined('ABSPATH') || exit;

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

// Proceso de subida y eliminación
add_action('admin_init', function () {
    // Subida
    if (
        isset($_POST['dm_file_upload_nonce']) &&
        wp_verify_nonce($_POST['dm_file_upload_nonce'], 'dm_file_upload')
    ) {
        dm_handle_file_upload();
    }

    // Eliminación
    if (
        isset($_POST['dm_delete_file']) &&
        current_user_can('delete_posts') &&
        wp_verify_nonce($_POST['_wpnonce'], 'dm_delete_file_' . $_POST['dm_delete_file'])
    ) {
        $attachment_id = intval($_POST['dm_delete_file']);
        dm_delete_document($attachment_id);
    }
});

/**
 * Renderiza el formulario de subida
 */
function dm_render_upload_form() {
    include DM_PLUGIN_PATH . 'templates/upload-form.php';
}

/**
 * Procesa la subida del archivo y guarda categoría, carpeta y JSON si es Excel.
 */
function dm_handle_file_upload() {
    if (!current_user_can('upload_files')) {
        DM_Logger::log('⛔ Usuario sin permisos intentó subir un archivo.');
        return;
    }

    if (!isset($_FILES['dm_file']) || $_FILES['dm_file']['error'] !== UPLOAD_ERR_OK) {
        DM_Logger::log('❌ Error al subir archivo: archivo no válido o con error.');
        return;
    }

    $file = $_FILES['dm_file'];

    $allowed_types = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'application/pdf',
        'text/csv'
    ];

    $file_type = wp_check_filetype($file['name']);
    if (!in_array($file_type['type'], $allowed_types)) {
        DM_Logger::log("❌ Tipo de archivo no permitido: " . $file['name']);
        return;
    }

    $upload = wp_handle_upload($file, ['test_form' => false]);

    if (isset($upload['error'])) {
        DM_Logger::log("❌ Error en subida de archivo: " . $upload['error']);
        return;
    }

    $attachment_id = wp_insert_attachment([
        'post_mime_type' => $upload['type'],
        'post_title'     => sanitize_file_name($file['name']),
        'post_content'   => '',
        'post_status'    => 'inherit',
    ], $upload['file']);

    require_once ABSPATH . 'wp-admin/includes/image.php';
    wp_update_attachment_metadata($attachment_id, wp_generate_attachment_metadata($attachment_id, $upload['file']));

    // Guardar categoría
    if (!empty($_POST['dm_category'])) {
        wp_set_object_terms($attachment_id, intval($_POST['dm_category']), 'document_category');
    }

    // Guardar carpeta
    if (!empty($_POST['dm_folder'])) {
        wp_set_object_terms($attachment_id, intval($_POST['dm_folder']), 'document_folder');
    }

    // Si es Excel, generar JSON para Luckysheet
    if (in_array($file_type['type'], [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-excel'
    ])) {
        try {
            $spreadsheet = IOFactory::load($upload['file']);
            $sheets_json = [];

            foreach ($spreadsheet->getAllSheets() as $index => $sheet) {
                $cellData = [];
                $highestRow = $sheet->getHighestRow();
                $highestColumn = Coordinate::columnIndexFromString($sheet->getHighestColumn());

                for ($row = 1; $row <= $highestRow; $row++) {
                    for ($col = 1; $col <= $highestColumn; $col++) {
                        $cellRef = Coordinate::stringFromColumnIndex($col) . $row;

                        if (!$sheet->cellExists($cellRef)) continue;

                        $cell = $sheet->getCell($cellRef);
                        $value = $cell->getFormattedValue();
                        if ($value === null || $value === '') continue;

                        $style = $sheet->getStyle($cellRef);
                        $font = $style->getFont();
                        $fill = $style->getFill();
                        $border = $style->getBorders();

                        $v = ['v' => $value];

                        // Color de fondo
                        $bgColor = $fill->getFillType() !== 'none' ? $fill->getStartColor()->getRGB() : null;
                        if ($bgColor && $bgColor !== 'FFFFFF') {
                            $v['bg'] = '#' . $bgColor;
                        }

                        // Color de texto
                        $fontColor = $font->getColor()->getRGB();
                        if ($fontColor && $fontColor !== '000000') {
                            $v['fc'] = '#' . $fontColor;
                        }

                        // Negrita
                        if ($font->getBold()) $v['bl'] = 1;

                        // Cursiva
                        if ($font->getItalic()) $v['it'] = 1;

                        // Tamaño fuente
                        if ($font->getSize()) $v['fs'] = (int)$font->getSize();

                        // Bordes
                        $borders = ['t' => 'top', 'b' => 'bottom', 'l' => 'left', 'r' => 'right'];
                        foreach ($borders as $key => $side) {
                            $borderStyle = $border->{'get' . ucfirst($side)}();
                            if ($borderStyle->getBorderStyle() !== 'none') {
                                $color = $borderStyle->getColor()->getRGB() ?: '000000';
                                $v['bd' . $key] = [
                                    'style' => 1,
                                    'color' => '#' . $color
                                ];
                            }
                        }

                        $cellData[] = [
                            'r' => $row - 1,
                            'c' => $col - 1,
                            'v' => $v
                        ];
                    }
                }

                $sheets_json[] = [
                    'name'     => $sheet->getTitle(),
                    'index'    => $index,
                    'celldata' => $cellData,
                    'config'   => new stdClass()
                ];
            }

            update_post_meta($attachment_id, '_dm_luckysheet_json', wp_json_encode($sheets_json));
            DM_Logger::log("✅ Excel convertido a JSON con estilos para ID {$attachment_id}");
        } catch (Throwable $e) {
            DM_Logger::log("❌ Error al convertir Excel a JSON: " . $e->getMessage());
        }
    }

    DM_Logger::log("✅ Archivo subido correctamente: " . $file['name']);
}

