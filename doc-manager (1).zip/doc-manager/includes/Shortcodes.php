<?php
/**
 * Shortcodes.php
 * 
 * Define shortcodes del plugin para mostrar formularios, listas o editores de documentos
 * dentro de páginas o entradas de WordPress.
 */

defined('ABSPATH') || exit;

// Shortcode para mostrar el formulario de subida de archivos
add_shortcode('dm_upload_form', 'dm_shortcode_upload_form');

/**
 * Renderiza el formulario de subida dentro de un post o página
 */
function dm_shortcode_upload_form() {
    ob_start();
    dm_render_upload_form(); // Usa la función del FileUploader
    return ob_get_clean();
}

// Shortcode para mostrar la lista de documentos
add_shortcode('dm_list_documents', 'dm_shortcode_list_documents');

/**
 * Muestra una tabla simple con los documentos subidos
 */
function dm_shortcode_list_documents() {
    $docs = dm_get_uploaded_documents();
    
    ob_start();

    if (empty($docs)) {
        echo '<p>No hay documentos cargados aún.</p>';
        return ob_get_clean();
    }

    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr><th>Nombre</th><th>Tipo</th><th>Subido</th><th>Acciones</th></tr></thead><tbody>';

    foreach ($docs as $doc) {
        $url = wp_get_attachment_url($doc->ID);
        $type = get_post_mime_type($doc->ID);
        $date = get_the_date('', $doc->ID);
        $title = esc_html($doc->post_title);

        echo "<tr>
                <td><a href='{$url}' target='_blank'>{$title}</a></td>
                <td>{$type}</td>
                <td>{$date}</td>
                <td>
                    <a href='{$url}' class='button' target='_blank'>Ver</a>
                </td>
              </tr>";
    }

    echo '</tbody></table>';

    return ob_get_clean();
}
