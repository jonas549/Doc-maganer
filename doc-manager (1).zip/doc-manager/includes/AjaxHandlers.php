<?php
// includes/AjaxHandlers.php

defined('ABSPATH') || exit;

/**
 * Handler para guardar archivo .xlsx físico (opcional)
 */
add_action('wp_ajax_dm_save_excel', 'dm_handle_excel_save');

function dm_handle_excel_save() {
    if (!current_user_can('upload_files')) {
        DM_Logger::log('⛔ Usuario sin permisos intentó guardar un Excel.');
        wp_send_json_error(['message' => 'No tienes permisos.']);
    }

    if (
        !isset($_FILES['file']) ||
        !isset($_POST['doc_id']) ||
        !is_numeric($_POST['doc_id'])
    ) {
        DM_Logger::log('❌ Datos incompletos al guardar Excel (POST: ' . json_encode($_POST) . ')');
        wp_send_json_error(['message' => 'Datos incompletos.']);
    }

    $doc_id = intval($_POST['doc_id']);
    $file   = $_FILES['file'];

    require_once ABSPATH . 'wp-admin/includes/file.php';

    $upload = wp_handle_upload($file, ['test_form' => false]);

    if (isset($upload['error'])) {
        DM_Logger::log('❌ Error al subir archivo: ' . $upload['error']);
        wp_send_json_error(['message' => 'Error al subir: ' . $upload['error']]);
    }

    $new_path  = $upload['file'];
    $mime_type = mime_content_type($new_path);

    update_attached_file($doc_id, $new_path);

    wp_update_post([
        'ID'                => $doc_id,
        'post_mime_type'    => $mime_type,
        'post_modified'     => current_time('mysql'),
        'post_modified_gmt' => current_time('mysql', 1),
    ]);

    update_post_meta($doc_id, '_dm_last_modified', current_time('mysql'));

    DM_Logger::log("✅ Excel guardado exitosamente para ID {$doc_id}");

    wp_send_json_success([
        'message' => 'Archivo guardado correctamente.',
        'url'     => wp_get_attachment_url($doc_id),
    ]);
}

/**
 * Nuevo handler para guardar JSON Luckysheet (con estilos y todo)
 */
add_action('wp_ajax_dm_save_excel_json', 'dm_handle_excel_json_save');

function dm_handle_excel_json_save() {
    if (!current_user_can('upload_files')) {
        DM_Logger::log('⛔ Sin permisos para guardar JSON.');
        wp_send_json_error(['message' => 'No tienes permisos.']);
    }

    if (
        !isset($_POST['doc_id'], $_POST['json_data']) ||
        !is_numeric($_POST['doc_id'])
    ) {
        DM_Logger::log('❌ Datos incompletos al guardar JSON (POST: ' . json_encode($_POST) . ')');
        wp_send_json_error(['message' => 'Datos incompletos.']);
    }

    $doc_id   = intval($_POST['doc_id']);
    $json_raw = wp_unslash($_POST['json_data']);

    if (!is_string($json_raw) || empty($json_raw)) {
        wp_send_json_error(['message' => 'JSON vacío o inválido.']);
    }

    // Guarda JSON como post_meta
    update_post_meta($doc_id, '_dm_luckysheet_json', $json_raw);
    update_post_meta($doc_id, '_dm_last_modified', current_time('mysql'));

    DM_Logger::log("✅ Luckysheet JSON guardado correctamente para ID {$doc_id}");

    wp_send_json_success([
        'message' => 'Guardado exitoso.'
    ]);
}
