<?php
/**
 * templates/edit-document.php
 * 
 * Vista para edición de documentos (fase inicial).
 * Aquí puedes renderizar una interfaz para editar archivos compatibles.
 * Se puede integrar OnlyOffice, Google Docs, u otra solución en el futuro.
 */

defined('ABSPATH') || exit;

// Verifica que haya un documento válido
if (!isset($_GET['doc_id']) || !is_numeric($_GET['doc_id'])) {
    echo '<p>Error: ID de documento no válido.</p>';
    return;
}

$doc_id = intval($_GET['doc_id']);
$doc_url = wp_get_attachment_url($doc_id);
$mime = get_post_mime_type($doc_id);

// Validar que sea un tipo soportado para edición (en el futuro esto puede ampliarse)
$supported_mime_types = [
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // Excel
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // Word
    'application/vnd.openxmlformats-officedocument.presentationml.presentation', // PPT
];

if (!in_array($mime, $supported_mime_types)) {
    echo '<p>Este tipo de documento no puede editarse en línea.</p>';
    return;
}
?>

<div class="dm-edit-document">
    <h2>Editar Documento</h2>

    <p><strong>Archivo:</strong> <?php echo esc_html(get_the_title($doc_id)); ?></p>

    <!-- Aquí puedes incrustar un editor externo (ej: OnlyOffice o Google Docs) -->
    <iframe 
        src="<?php echo esc_url($doc_url); ?>" 
        width="100%" 
        height="600px" 
        style="border: 1px solid #ccc;"
    >
    </iframe>

    <p>Nota: Esta vista usa un <code>iframe</code> para mostrar el documento. En el futuro puedes integrar un editor real aquí.</p>
</div>
