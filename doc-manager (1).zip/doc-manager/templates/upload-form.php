<?php
/**
 * templates/upload-form.php
 * 
 * Formulario de subida con categoría y carpeta.
 */

defined('ABSPATH') || exit;
?>

<div class="dm-upload-form">
    <h2>Subir nuevo documento</h2>

    <form method="post" enctype="multipart/form-data">
        <?php wp_nonce_field('dm_file_upload', 'dm_file_upload_nonce'); ?>

        <p>
            <label for="dm_file"><strong>Seleccionar archivo (Excel, Word, PPT):</strong></label><br>
            <input type="file" name="dm_file" id="dm_file" required accept=".xlsx,.xls,.docx,.pptx,.csv,.pdf">
        </p>

        <p>
            <label for="dm_category"><strong>Seleccionar categoría:</strong></label><br>
            <select name="dm_category" id="dm_category" required>
                <option value="">-- Selecciona una categoría --</option>
                <?php
                $terms = get_terms([
                    'taxonomy'   => 'document_category',
                    'hide_empty' => false,
                ]);
                foreach ($terms as $term) {
                    echo '<option value="' . esc_attr($term->term_id) . '">' . esc_html($term->name) . '</option>';
                }
                ?>
            </select>
        </p>

        <p>
            <label for="dm_folder"><strong>Seleccionar carpeta:</strong></label><br>
            <select name="dm_folder" id="dm_folder" required>
                <option value="">-- Selecciona una carpeta --</option>
                <?php
                $folders = get_terms([
                    'taxonomy'   => 'document_folder',
                    'hide_empty' => false,
                ]);
                foreach ($folders as $folder) {
                    echo '<option value="' . esc_attr($folder->term_id) . '">' . esc_html($folder->name) . '</option>';
                }
                ?>
            </select>
        </p>

        <p>
            <input type="submit" value="Subir archivo" class="button button-primary">
        </p>
    </form>
</div>

