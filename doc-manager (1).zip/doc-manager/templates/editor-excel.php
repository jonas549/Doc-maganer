<?php
/**
 * templates/editor-excel.php
 * 
 * Editor Luckysheet con soporte para guardar estilos vía JSON.
 */
defined('ABSPATH') || exit;

// Validación defensiva
if (!isset($doc_id, $title, $last_modified)) {
    echo '<div class="notice notice-error"><p>Error: datos del documento incompletos.</p></div>';
    return;
}

// Obtener JSON guardado desde post_meta
$json_data = get_post_meta($doc_id, '_dm_luckysheet_json', true);

// Si no hay JSON, inicializa una hoja vacía
if (empty($json_data)) {
    $json_data = json_encode([
        [
            'name'     => 'Hoja1',
            'celldata' => [],
            'index'    => 0,
            'config'   => new stdClass()
        ]
    ]);
}
?>

<div class="wrap">
    <h1>Editar Excel: <?php echo esc_html($title); ?></h1>
    <p><strong>Última modificación:</strong>
        <?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($last_modified))); ?>
    </p>

    <!-- Hidden inputs para JS -->
    <input type="hidden" id="dm_excel_doc_id" value="<?php echo esc_attr($doc_id); ?>">
    <input type="hidden" id="dm_excel_json_data" value='<?php echo esc_attr($json_data); ?>'>

    <button id="dm-excel-save" class="button button-primary" style="margin-bottom: 15px;">Guardar</button>
    <a href="<?php echo wp_get_attachment_url($doc_id); ?>" class="button" target="_blank" style="margin-left: 10px;">Ver archivo</a>

    <span id="dm-excel-status" style="margin-left: 15px;"></span>

    <div id="luckysheet" style="width: 100%; height: 700px; border: 1px solid #ccc;"></div>
</div>

<!-- Viewport para móviles -->
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Luckysheet CSS desde CDN -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/luckysheet@latest/dist/plugins/css/plugins.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/luckysheet@latest/dist/plugins/css/pluginsCss.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/luckysheet@latest/dist/assets/iconfont/iconfont.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/luckysheet@latest/dist/css/luckysheet.css">

<!-- Luckysheet JS desde CDN -->
<script src="https://cdn.jsdelivr.net/npm/luckysheet@latest/dist/plugins/js/plugin.js"></script>
<script src="https://cdn.jsdelivr.net/npm/luckysheet@latest/dist/luckysheet.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>

<!-- ajaxurl global para JS -->
<script>var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";</script>

<!-- Tu script personalizado separado -->
<?php
wp_enqueue_script(
    'dm-editor-excel',
    DM_PLUGIN_URL . 'assets/editor-excel.js',
    [], // Puedes agregar dependencias si lo deseas
    DM_PLUGIN_VERSION,
    true
);
?>
