<?php
defined('ABSPATH') || exit;

// Filtros
$selected_category = isset($_GET['filter_category']) ? intval($_GET['filter_category']) : '';
$selected_folder   = isset($_GET['filter_folder']) ? intval($_GET['filter_folder']) : '';
$search_query      = isset($_GET['search_document']) ? sanitize_text_field($_GET['search_document']) : '';

$args = [];

if ($search_query) {
    $args['s'] = $search_query;
}

if ($selected_category || $selected_folder) {
    $args['tax_query'] = ['relation' => 'AND'];

    if ($selected_category) {
        $args['tax_query'][] = [
            'taxonomy' => 'document_category',
            'field'    => 'term_id',
            'terms'    => $selected_category,
        ];
    }

    if ($selected_folder) {
        $args['tax_query'][] = [
            'taxonomy' => 'document_folder',
            'field'    => 'term_id',
            'terms'    => $selected_folder,
        ];
    }
}

$documents = dm_get_uploaded_documents($args);
?>

<div class="dm-document-list">
    <h2>Lista de Documentos</h2>

    <form method="get" style="margin-bottom: 20px;">
        <input type="hidden" name="page" value="doc-manager">
        <input type="text" name="search_document" placeholder="Buscar por nombre..." value="<?php echo esc_attr($search_query); ?>" style="min-width: 200px; margin-right: 10px;">

        <select name="filter_category" onchange="this.form.submit()">
            <option value="">Todas las categorías</option>
            <?php
            $cats = get_terms(['taxonomy' => 'document_category', 'hide_empty' => false]);
            foreach ($cats as $cat) {
                $selected = selected($selected_category, $cat->term_id, false);
                echo "<option value='{$cat->term_id}' $selected>{$cat->name}</option>";
            }
            ?>
        </select>

        <select name="filter_folder" onchange="this.form.submit()" style="margin-left: 10px;">
            <option value="">Todas las carpetas</option>
            <?php
            $folders = get_terms(['taxonomy' => 'document_folder', 'hide_empty' => false]);
            foreach ($folders as $folder) {
                $selected = selected($selected_folder, $folder->term_id, false);
                echo "<option value='{$folder->term_id}' $selected>{$folder->name}</option>";
            }
            ?>
        </select>

        <button type="submit" class="button">Filtrar</button>
    </form>

    <?php if (empty($documents)) : ?>
        <p>No hay documentos encontrados.</p>
    <?php else : ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Tipo</th>
                    <th>Categoría</th>
                    <th>Carpeta</th>
                    <th>Fecha de subida</th>
                    <th>Última modificación</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($documents as $doc) : ?>
                    <?php
                    $url           = wp_get_attachment_url($doc->ID);
                    $title         = esc_html($doc->post_title);
                    $mime          = esc_html(get_post_mime_type($doc->ID));
                    $date_uploaded = esc_html(get_the_date('', $doc->ID));

                    // Última modificación (meta personalizada o fallback)
                    $last_modified = get_post_meta($doc->ID, '_dm_last_modified', true);
                    if (!$last_modified) {
                        $last_modified = $doc->post_modified;
                    }

                    $last_modified = $last_modified && strtotime($last_modified)
                        ? date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($last_modified))
                        : '—';

                    $cats          = wp_get_post_terms($doc->ID, 'document_category', ['fields' => 'names']);
                    $folders       = wp_get_post_terms($doc->ID, 'document_folder', ['fields' => 'names']);
                    $cat_output    = !empty($cats) ? implode(', ', $cats) : '—';
                    $folder_output = !empty($folders) ? implode(', ', $folders) : '—';
                    ?>
                    <tr>
                        <td><a href="<?php echo esc_url($url); ?>" target="_blank"><?php echo $title; ?></a></td>
                        <td><?php echo $mime; ?></td>
                        <td><?php echo esc_html($cat_output); ?></td>
                        <td><?php echo esc_html($folder_output); ?></td>
                        <td><?php echo $date_uploaded; ?></td>
                        <td><?php echo esc_html($last_modified); ?></td>
                        <td style="display: flex; gap: 5px;">
                            <?php
                            // Mostrar botón de edición solo si es tipo compatible
                            if ($mime === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') :
                            ?>
                                <a href="<?php echo admin_url('admin.php?page=doc-manager-edit-excel&doc_id=' . $doc->ID); ?>" class="button">Editar Excel</a>
                            <?php elseif (in_array($mime, [
                                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                                'application/vnd.openxmlformats-officedocument.presentationml.presentation'
                            ])) : ?>
                                <a href="<?php echo admin_url('admin.php?page=doc-manager-edit&doc_id=' . $doc->ID); ?>" class="button">Editar</a>
                            <?php endif; ?>

                            <form method="post" onsubmit="return confirm('¿Eliminar este documento?');">
                                <input type="hidden" name="dm_delete_file" value="<?php echo esc_attr($doc->ID); ?>">
                                <?php wp_nonce_field('dm_delete_file_' . $doc->ID); ?>
                                <button type="submit" class="button button-secondary">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
