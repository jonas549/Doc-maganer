window.addEventListener("DOMContentLoaded", function () {
    console.log("🚀 Luckysheet editor cargando...");

    const docIdField = document.getElementById("dm_excel_doc_id");
    const jsonDataField = document.getElementById("dm_excel_json_data");
    const saveBtn = document.getElementById("dm-excel-save");
    const status = document.getElementById("dm-excel-status");

    if (!docIdField || !jsonDataField) {
        console.error("❌ Campos ocultos no encontrados");
        return;
    }

    const docId = docIdField.value;
    const initialJson = jsonDataField.value;
    let isLuckysheetReady = false;

    /**
     * Inicializa Luckysheet con los datos cargados desde PHP
     */
    function initLuckysheet(jsonString) {
        try {
            const data = JSON.parse(jsonString);
            if (!Array.isArray(data)) throw new Error("JSON no contiene una lista de hojas");

            luckysheet.create({
                container: "luckysheet",
                title: "Luckysheet Editor",
                lang: "es",
                data: data,
                showinfobar: true,
                showsheetbar: true,
                showtoolbar: true,
                showstatisticBar: true,
                allowEdit: true,
                enableAddRow: true,
                enableAddCol: true,
                forceCalculation: false,
                showRowBar: true,
                showColumnBar: true,
                sheetBottomConfig: {
                    add: true,
                    menu: true,
                    sheet: true,
                    zoom: true
                }
            });

            isLuckysheetReady = true;
            console.log("✅ Luckysheet inicializado");
        } catch (err) {
            console.error("❌ Error al parsear JSON Luckysheet:", err);
            status.textContent = "❌ Error al cargar el documento.";
        }
    }

    /**
     * Guarda el estado actual del editor como JSON
     */
    function saveLuckysheetData() {
        if (!isLuckysheetReady) {
            alert("Luckysheet aún no está listo.");
            return;
        }

        status.textContent = "Guardando...";

        try {
            const sheets = luckysheet.getAllSheets();
            const json = JSON.stringify(sheets);

            const formData = new FormData();
            formData.append("action", "dm_save_excel_json");
            formData.append("doc_id", docId);
            formData.append("json_data", json);

            fetch(ajaxurl, {
                method: "POST",
                body: formData
            })
                .then((res) => res.json())
                .then((res) => {
                    if (res.success) {
                        status.innerHTML = `✅ Guardado correctamente`;
                    } else {
                        status.textContent = "❌ Error al guardar: " + (res.data?.message || "Desconocido");
                    }
                })
                .catch((err) => {
                    console.error("Fetch error:", err);
                    status.textContent = "❌ Error de red al guardar.";
                });
        } catch (e) {
            console.error("❌ Error al generar JSON desde Luckysheet:", e);
            status.textContent = "❌ Error al preparar los datos para guardar.";
        }
    }

    // Inicializa Luckysheet al cargar
    initLuckysheet(initialJson);

    // Botón de guardar
    if (saveBtn) {
        saveBtn.addEventListener("click", saveLuckysheetData);
    }
});
