/**
 * main.js
 * 
 * Archivo JS principal del plugin Document Manager.
 * Aquí se manejarán futuras funciones como:
 * - Filtros dinámicos
 * - Paginación con AJAX
 * - Edición en línea
 * - Alertas o interacciones del formulario
 */

document.addEventListener('DOMContentLoaded', function () {
    console.log('Document Manager JS cargado');

    // Ejemplo: alerta al seleccionar un archivo
    const fileInput = document.querySelector('#dm_file');
    if (fileInput) {
        fileInput.addEventListener('change', function () {
            if (this.files.length > 0) {
                alert(`Archivo seleccionado: ${this.files[0].name}`);
            }
        });
    }

    // Aquí vendrán más funcionalidades JS a medida que se agregue lógica interactiva
});
